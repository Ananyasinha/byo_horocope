<?php 
 require_once('include/config.php');

   $select = "SELECT * FROM pages WHERE page_id=2";
   $selected = $conn->query($select);
   $row = $selected->fetch_assoc();
   $content =$row['page_content'];
   $title =$row['page_title'];

   $selectQ = "SELECT * FROM general_details";
   $selectedQ = $conn->query($selectQ);
   $rowQ = $selectedQ->fetch_assoc();

 $blink= 'http://localhost/genesis/dashboard/media/img/banners/';

include ('include/header.php');

?>
    <section id="inner-page-banner" class="inner-about">
        <div class="container">
            <div class="page-heading">
                <h1>About Us</h1></div>

        </div>
        <div class="brad">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a href="#">Home</a></li>
                    <li>About Us</li>
                </ul>
            </div>
        </div>
    </section>
    <section id="first-section">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <h2 class="page-section-title"><?php echo $title;?></h2>
                  <!--   <p> -->
                        <!-- <h1 class="section-title ab-hom"><?php echo $title;?></h1> -->
                   <p><?php echo $content;?></p>



                   <!--  GENESIS IT INNOVATIONS LIMITED (GITIL) provides complete audio video digital display control managed product integration and lighting dimming solutions to the largest and most sophisticated clients from various domain across India.</p>
                    <p>Our customers include most future forward looking <strong>Corporate, IT, ITes ,Real Estate Developers, Educational Institutes, Hospitals and Hospitality Segment.</strong></p>
                    <p>GITIL is committed to serve our customers by enabling them to reduce their carbon foot print and energy costs by delivering products and services that will serve for years. GITIL management services designs and up keeps the digital infrastructure to ensure maximum results for our customers.</p> -->
                </div>
                <div class="col-md-4 text-center">
                    <img src="images/about-us.png" alt="about-us" class="img-fluid ab-img">
                </div> 
            </div>
        </div>
    </section>
    <section id="second-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <h3 class="orga carrer">Who We Are?</h3>
                    <ul class="ulico">
                        <li>We Are Pioneers In Av Integration, Coupled With The Most Important Part, Often Neglected Integrators, - Maintenance And Services.</li>
                        <li><strong>DESIGN</strong> : We Have A Dedicated Team Who Will Provide Cad Drawing Based On Yours Applications And Task.</li>
                        <li><strong>SUPPLY </strong>: We Have For You A Separate Procurement & Logistic Team, Who Will Ensure Project Equipment To Be Available With In Stipulated Time Frame And Also Offer Unique USD Consolidated Billing For SEZ/STPI/EON And IT Parks.</li>
                        <li><strong>BUILD </strong>: We Have Dedicated Team Of 126 Plus Comprising Of Implementation Engineering And Qualified Technicians , Who Adhere To 35 Points Implementation Check list Along With Support Team.</li>
                        <li><strong>SUPPORT </strong>: We Have Dedicated 24/7 Support Help Line Comprising 60 Plus Team After Installation .</li>
                    </ul>
                    <a href="contact-us.php" class="read-more con-us"> Contact Us</a>
                </div>

                <div class="col-md-6">
                    <h3 class="orga carrer">Key Facts</h3>
                    <ul class="ulico">
                        <li> Successfully Completed Working Closely With Leading Consultant Doug Allen In Chicago ,USA For Kanbay (Cap Gemini Project) Which Till Date Is The Largest AV Integration Project In India.</li>
                        <li><strong>Offices</strong> : Serve You Across Offices ,Support Centers In Bangalore, Pune, Chennai,Mumbai,Hyderabad. Project Capabilities PAN India.</li>
                        <li>300+ Existing Clients And 10000+ Installations PAN India Includes Govt Sectors, IT Parks, Banks, Hospitals, Hotels Educational Institutes.</li>
                        <li>Team Size Of 120 Plus Industry Leaders With Largest Trained Manpower Certified Manpower Of Major Principals Like Polycom Crestron ,Extron, AMX,Clearone etc…….</li>
                        <li>Genesis Has Grown As A System Integrator Of Repute With A Clientele Which Includes The Fortune 500 Companies. Total Team Experience For Install And Engineering 400 Plus Years.</li>
                    </ul>
                </div>

            </div>
        </div>
    </section>

    <?php include ('include/footer.php');?>