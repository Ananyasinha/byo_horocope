<?php 
    require_once('include/config.php');

     $select = "SELECT * FROM pages WHERE page_id=6";
     $selected = $conn->query($select);
     $row = $selected->fetch_assoc();
     $content =$row['page_content'];
     $title =$row['page_title'];
     $page_name =$row['page_name'];
     $sub_title=$row['page_sub_title'];


    include ('include/header.php');

?>
<section id="inner-page-banner" class="inner-about">
    <div class="container">
        <div class="page-heading">
            <h1><?php echo ucfirst($page_name);?></h1>
        </div>

    </div>
    <div class="brad">
        <div class="container">
            <ul class="breadcrumb">
                <li><a href="#">Home</a></li>
                <li>Career</li>
            </ul>
        </div>
    </div>
</section>
<section>
    <div class="container">
        <div class="col-md-12">
            <?php echo $content;?>
            
        </div>
    </div>
</section>
<section id="second-section" class="syllabus pb-3">
    <div class="container">
        <h2 class="page-section-title center-title text-center mb-5">Why do we use it?</h2>
        <div class="col-md-4">
            <div class="inner-self">
                <div class="left-content-syl"><i class="fa fa-info"></i></div>
                <div class="right-content-syl">
                    <h5>Typesetting industry Lorem</h5></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text Lorem Ipsum is simply dummy text of the printing.</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="inner-self">
                <div class="left-content-syl"><i class="fa fa-file"></i></div>
                <div class="right-content-syl">
                    <h5>Typesetting industry Lorem</h5></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text Lorem Ipsum is simply dummy text of the printing.</p>

            </div>
        </div>
        <div class="col-md-4">
            <div class="inner-self">
                <div class="left-content-syl"><i class="fa fa-bitbucket"></i></div>
                <div class="right-content-syl">
                    <h5>Typesetting industry Lorem</h5></div>
                <div class="clearfix"></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text Lorem Ipsum is simply dummy text of the printing.</p>

            </div>
        </div>
        <div class="col-md-4">
            <div class="inner-self">
                <div class="left-content-syl"><i class="fa fa-check-square-o"></i></div>
                <div class="right-content-syl">
                    <h5>Typesetting industry Lorem</h5></div>
                <div class="clearfix"></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text Lorem Ipsum is simply dummy text of the printing.</p>

            </div>
        </div>
        <div class="col-md-4">
            <div class="inner-self">
                <div class="left-content-syl"><i class="fa fa-file-text-o"></i></div>
                <div class="right-content-syl">
                    <h5>Typesetting industry Lorem</h5></div>
                <div class="clearfix"></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text Lorem Ipsum is simply dummy text of the printing.</p>

            </div>
        </div>
        <div class="col-md-4">
            <div class="inner-self">
                <div class="left-content-syl"><i class="fa fa-calendar"></i></div>
                <div class="right-content-syl">
                    <h5>Typesetting industry Lorem</h5></div>
                <div class="clearfix"></div>
                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text Lorem Ipsum is simply dummy text of the printing.</p>
            </div>
        </div>
    </div>
    </div>
</section>
<section id="first-section">
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <h3 class="orga mt-3">It is a long established fact that a reader will be <span>syllabus affect?</span></h3>
                <p class="mt-4 con-jus">There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form. Audio video digital display control managed product integration and lighting dimming solutions to the largest.</p>
                <p class="con-tex"><a href="contact-us.php" class="read-more con-us mt-4"> Contact Us</a></p>
            </div>
            <div class="col-md-4 text-center">
                <img src="images/crrer-1.png" alt="about-us" class="img-fluid ab-img">
            </div>
        </div>
    </div>
</section>

<?php include ('include/footer.php');?>