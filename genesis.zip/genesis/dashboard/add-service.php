<?php require_once('inc/config.php');

if(empty($_SESSION['user'])){
     header('location:login.php');
 }

$menu ="site-page2";
$subMenu ="addservice";
$pageName = "Add Page Details";



//update company details...
if(isset($_POST['add-info'])){
  $name        = mysqli_real_escape_string($conn, $_POST['page-name']);
  $title       = mysqli_real_escape_string($conn, $_POST['page-title']);
  $pagecontent = mysqli_real_escape_string($conn, $_POST['page-content']);
  $metatitle   = mysqli_real_escape_string($conn, $_POST['meta-title']);
  $metadesc    = mysqli_real_escape_string($conn, $_POST['description']);
  $metakey     = mysqli_real_escape_string($conn, $_POST['meta-keyword']);
  $service_page_id = 4;

    $add = "INSERT INTO `sub_service_page`(`page_id`,`sub_page_name`,`service_title`, `full_content`,`sub_meta_title`,`sub_meta_desc`,`sub_meta_keyword`,`created_on`) VALUES ('$service_page_id','$name','$title', '$pagecontent','$metatitle','metadesc','$metakey','$datetime')";
    $added = $conn->query($add);

    if($added){
       header("location:service-list.php");
      $_SESSION['toast']['type'] = "success";
      $_SESSION['toast']['msg'] = "Services Details successfully .";
      exit();
    }else{
      $_SESSION['toast']['type'] = "danger";
      $_SESSION['toast']['msg'] = "Something went wrong, Please try again.";
  }
}



?>
<!DOCTYPE html>
<html lang="en" class="perfect-scrollbar-on">
  <head>
    <!-- include meta.php and css.php here -->
    <title><?php echo $pageName;?>  | GENESIS</title>
    <?php 
      include_once('inc/meta.php');
      include_once('inc/css.php');
    ?>
    <!-- include meta.php and css.php here -->
  </head>

<body class="" style="overflow: auto !important;">
  <div class="wrapper" style="overflow: auto !important;">
    <!-- include navbar.php here -->
    <?php include_once('inc/navbar.php');?>
    <!-- include navbar.php here -->

    <div class="main-panel ps-container ps-theme-default ps-active-y" data-ps-id="17311806-fdb4-3c63-4aa5-9896dd7868a3">
      <!-- include header.php here -->
      <?php include_once('inc/header.php');?>
      <!-- include header.php here -->

      <!-- main content body start-->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12">

              <div class="row">
                <div class="col-md-12">
                  <div class="card">
                    <div class="card-header card-header-danger theme-color">
                      <h4 class="card-title">Create New service Page</h4>
                    </div>
                    <div class="card-body">
                      <form method="post" enctype="multipart/form-data">
                        <div class="row">
                          <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating">Service Page Name * </label>
                              <input type="text" name="page-name" class="form-control">
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating">Page Title * </label>
                              <input type="text" name="page-title"  class="form-control" value="<?php echo $getData['page_title']?>" required>
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating">Page Content</label>
                              <input type="text" name="page-content"  class="form-control" value="<?php echo $getData['page_content']?>" disabled="">
                              <textarea class="form-control ckeditor"  name="page-content"  id="page-content" size="15"></textarea>
                            </div>
                          </div>
                        </div>

        
                        <div class="row">
                          <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating">Meta Title (Maximum 50-60 Characters)</label>
                              <input type="text" name="meta-title" class="form-control" value="">
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating">Meta Description</label>
                              <input type="text" name="description"  class="form-control" value="">
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating">Meta Keywords (Use Comma ',' in between keywords)</label>
                              <textarea name="meta-keyword" class="form-control" rows="5"></textarea>
                            </div>
                          </div>
                        </div>
                        <button type="submit" name="add-danger" class="btn btn-danger theme-btn">Save</button>
                        <div class="clearfix"></div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main content body end-->

      
      <!-- incude footer.php here-->
      <?php include_once('inc/footer.php'); ?>
      <!-- incude footer.php here-->

    </div><!-- main panel end -->
  </div><!-- wrapper end -->
  <!-- include js.php here -->
  <?php include_once('inc/js.php'); ?>
  <!-- include js.php here -->
  <script src="ckeditor/ckeditor/ckeditor.js"></script>
  <script src="ckeditor/ckfinder/ckfinder.js"></script>


  <script type="text/javascript">
  var editor = CKEDITOR.replace( 'order_summary', {
      filebrowserBrowseUrl : 'ckeditor/ckfinder/ckfinder.html',
      filebrowserImageBrowseUrl : 'ckeditor/ckfinder/ckfinder.html?type=Images',
      filebrowserFlashBrowseUrl : 'ckeditor/ckfinder/ckfinder.html?type=Flash',
      filebrowserUploadUrl : 'ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Files',
      filebrowserImageUploadUrl : 'ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Images',
      filebrowserFlashUploadUrl : 'ckeditor/ckfinder/core/connector/php/connector.php?command=QuickUpload&type=Flash'
  });
  CKFinder.setupCKEditor( editor, '../' );
  </script>  
</body>
</html>