<?php require_once('inc/config.php');

if(empty($_SESSION['user'])){
     header('location:login.php');
 }

$menu ="site-page1";
$subMenu ="addtestimonial";
$pageName = "Add Testimonial";

//add details...
if(isset($_POST['add-info'])){
  $name        = mysqli_real_escape_string($conn, $_POST['username']);
  $description = mysqli_real_escape_string($conn, $_POST['description']);

  $add = "INSERT INTO `testimonial`(`name`,`description`,`created_on`) VALUES ('$name','$description','$datetime')";
  $added = $conn->query($add);

    if($added){
      header("location:list-testimonial.php");
      $_SESSION['toast']['type'] = "success";
      $_SESSION['toast']['msg'] = "Testimonial Details successfully .";
      exit();
    }else{
      $_SESSION['toast']['type'] = "danger";
      $_SESSION['toast']['msg'] = "Something went wrong, Please try again.";
  }
}



?>
<!DOCTYPE html>
<html lang="en" class="perfect-scrollbar-on">
  <head>
    <!-- include meta.php and css.php here -->
    <title><?php echo $pageName;?>  | INDRAW</title>
    <?php 
      include_once('inc/meta.php');
      include_once('inc/css.php');
    ?>
    <!-- include meta.php and css.php here -->
  </head>

<body class="" style="overflow: auto !important;">
  <div class="wrapper" style="overflow: auto !important;">
    <!-- include navbar.php here -->
    <?php include_once('inc/navbar.php');?>
    <!-- include navbar.php here -->

    <div class="main-panel ps-container ps-theme-default ps-active-y" data-ps-id="17311806-fdb4-3c63-4aa5-9896dd7868a3">
      <!-- include header.php here -->
      <?php include_once('inc/header.php');?>
      <!-- include header.php here -->

      <!-- main content body start-->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-12">

              <div class="row">
                <div class="col-md-10 mr-auto ml-auto">
                  <div class="card">
                    <div class="card-header card-header-info theme-color">
                      <h4 class="card-title">Add New Testimonial</h4>
                    </div>
                    <div class="card-body">
                      <form method="post" enctype="multipart/form-data">
                        <div class="row">
                          <div class="col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating"> Description *</label>
                               <textarea name="description" class="form-control" rows="3" required=""></textarea>
                            </div>
                          </div>
                        </div>

                        <div class="row">
                          <div class="col-sm-12 col-md-12">
                            <div class="form-group">
                              <label class="bmd-label-floating">Name*</label>
                              <input type="text" name="username" class="form-control" required="">
                            </div>
                          </div>
                        </div>

                        <button type="submit" name="add-info" class="btn btn-info theme-btn">Save</button>
                        <div class="clearfix"></div>
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- main content body end-->

      
      <!-- incude footer.php here-->
      <?php include_once('inc/footer.php'); ?>
      <!-- incude footer.php here-->

    </div><!-- main panel end -->
  </div><!-- wrapper end -->
  <!-- include js.php here -->
  <?php include_once('inc/js.php'); ?>
  <!-- include js.php here -->

</body>
</html>