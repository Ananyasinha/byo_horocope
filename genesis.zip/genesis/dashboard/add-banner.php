<?php require_once('inc/config.php');
$menu ="site-page";
$subMenu ="banner";
$pageName = "Add banner";


//update logo...
if(isset($_POST['update-banner'])){
  $tmpName = $_FILES['img']['tmp_name'];

  if(file_exists($tmpName)==true){
    $type     = mysqli_real_escape_string($conn, $_POST['banner-type']);
    $title    = mysqli_real_escape_string($conn, $_POST['title']);
    $subtitle = mysqli_real_escape_string($conn, $_POST['subtitle']);

    $fileName = $_FILES['img']['name'];
    $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
    $fileName = rand('11111','99999').'-'.time().'.'.$fileExt;
    $folder = 'media/img/banners/';

    if(move_uploaded_file($tmpName, $folder.''.$fileName)==true){
      if(isset($_GET['id'])){
        $id = mysqli_real_escape_string($conn, $_GET['id']);

        $actionQ = "UPDATE `site_banners` SET `type`='$type',`image`='$fileName',`status`=2 WHERE id=".$id;
      }else{
        $actionQ = "INSERT INTO `site_banners`(`type`,`image`,`title`,`sub_title`,`status`) VALUES ('$type','$fileName','$title','$subtitle',2)";
      }

      if(mysqli_query($conn, $actionQ)==true){
        $getQ = "SELECT `id`,`type`,`image` FROM `site_banners` WHERE `status`=2";
        $getQ =mysqli_query($conn, $getQ);
        while ($getData = mysqli_fetch_assoc($getQ)) {
          //$_SESSION['banner'][$getData['type']][]= $getData['img'];
        }
        $_SESSION['toast']['type']="success";
        $_SESSION['toast']['msg'] = "Image successfully uploaded.";
      }else{
         $_SESSION['toast']['type']="danger";
        $_SESSION['toast']['msg'] = "Something went wrong, Please try again.";
      }
    }else{
       $_SESSION['toast']['type']="danger";
      $_SESSION['toast']['msg'] = "Something went wrong, Please try again.";
    }
  }else{
    $_SESSION['toast']['type']="info";
    $_SESSION['toast']['msg'] = "Please select an image file.";
  }
}

?>
<!DOCTYPE html>
<html lang="en" class="perfect-scrollbar-on">
  <head>
    <!-- include meta.php and css.php here -->
    <title>General Details | GENESIS</title>
    <?php 
      include_once('inc/meta.php');
      include_once('inc/css.php');
    ?>
    <!-- include meta.php and css.php here -->
  </head>

<body class="" style="overflow: auto !important;">
  <div class="wrapper" style="overflow: auto !important;">
    <!-- include navbar.php here -->
    <?php include_once('inc/navbar.php');?>
    <!-- include navbar.php here -->

    <div class="main-panel ps-container ps-theme-default ps-active-y" data-ps-id="17311806-fdb4-3c63-4aa5-9896dd7868a3">
      <!-- include header.php here -->
      <?php include_once('inc/header.php');?>
      <!-- include header.php here -->

      <!-- main content body start-->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
              <div class="col-sm-8 ml-auto mr-auto">
                <div class="card">
                  <div class="card-header card-header-danger theme-color">
                    <h4 class="card-title"><?php echo $pageName;?></h4>
                  </div>
                  <div class="card-body">
                    <div class="card">
                      <div class="card-body">
                        <form method="post" enctype="multipart/form-data">
                          <div class="row" style="padding: 20px;">
                            <div class="col-md-12">
                              <div class="input-group">
                                <select name="banner-type" class="form-control" required="">
                                  <option value="" disabled="" selected="">Select Banner Type</option>
                                  <?php
                                  foreach (banner_type(0) as $key => $value) {
                                    echo  '<option value="'.$key.'">' .$value. '</option>';
                                  }
                                  ?>
                                </select>
                              </div>
                            </div>
                          </div>

                          <div class="row" style="padding: 20px;">
                            <div class="col-md-12">
                              <div class="input-group">
                               <label class="bmd-label-floating">Title </label> 
                                <input id="title" class="form-control file-path validate" type="text" name="title" value="<?php if(isset($_GET['id'])){ echo $getData['title'];}?>">
                              </div>
                            </div>
                          </div>

                           <div class="row" style="padding: 20px;">
                            <div class="col-md-12">
                              <div class="input-group">
                                <label class="bmd-label-floating"> Sub Tilte</label>
                                 <textarea class="form-control" rows="3" name="subtitle"></textarea>
                              </div>
                            </div>
                          </div> 

                          <div class="row" style="padding: 20px;">
                            <div class="col-md-12">
                              <div class="input-group">
                                <input type="file" name="img" accept="image/*" class="form-control" required="">
                              </div>
                            </div>
                          </div>

                          <button type="submit" name="update-banner" class="btn btn-danger theme-btn">Upload</button>
                          <div class="clearfix"></div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
      <!-- main content body end-->

       <!-- add more button start -->
      <div class="btn-float-bottom-right">
        <a href="manage-banners.php" class="theme-btn" rel="tooltip" data-original-title="Go Back"><i class="material-icons">reply</i></a>
      </div>
      <!-- add more button start -->

      <!-- incude footer.php here-->
      <?php include_once('inc/footer.php'); ?>
      <!-- incude footer.php here-->

    </div><!-- main panel end -->
  </div><!-- wrapper end -->
  <!-- include js.php here -->
  <?php include_once('inc/js.php'); ?>
  <!-- include js.php here -->
</body>
</html>