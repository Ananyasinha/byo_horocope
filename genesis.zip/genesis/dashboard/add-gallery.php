<?php require_once('inc/config.php');
$menu ="gallery-page";
$subMenu ="addgallery";
$pageName = "Create Gallery";

//update gallery...
  function make_rand($one, $two, $three) {
      $id = substr(uniqid(md5((hash('md5', hash('md5', $one) . $two) . $three))), 0, 10);
      return $id;
  }

  $id  = 1; 
 // $datetime   = date("Y-m-d H:i:s");
  if(isset($_POST['uplode_media'])) {

    for($i = 0; $i < count($_FILES["upload_file"]["name"]); $i++){
      $uploadfile   = $_FILES["upload_file"]["tmp_name"][$i];
      $extension    = explode(".",$_FILES["upload_file"]["name"][$i])[1];

      if(strtoupper($extension) == "JPG" || strtoupper($extension) == "PNG" || strtoupper($extension) == "JPEG" || strtoupper($extension) == "GIF"){
         $folder = 'media/img/gallery/';
      }
      $rand_number   = make_rand($id,$datetime,rand('11111','99999'));
      $new_name      = 'img'."_".$rand_number;
      $images        = "";
    
      if(strtoupper($extension) == "JPG" || strtoupper($extension) == "PNG" || strtoupper($extension) == "JPEG" || strtoupper($extension) == "GIF"){
          $images    = $new_name.'.'.$extension;
      }

      move_uploaded_file($_FILES["upload_file"]["tmp_name"][$i], "$folder".$images);

      $insert = "INSERT INTO `site_gallery`(`image`,`status`,`created_on`) VALUES ('$images', 2,'$datetime')";
      $inserted = $conn->query($insert);
    }

    if($inserted){
      // header("location:.php");
      $_SESSION['toast']['type']="success";
      $_SESSION['toast']['msg'] = "Image successfully uploaded.";
    }else{
      $_SESSION['toast']['msg'] = "Something went wrong, Please try again.";
    }
  }
?>
<!DOCTYPE html>
<html lang="en" class="perfect-scrollbar-on">
  <head>
    <!-- include meta.php and css.php here -->
    <title>General Details | GENESIS</title>
    <?php 
      include_once('inc/meta.php');
      include_once('inc/css.php');
    ?>
    <!-- include meta.php and css.php here -->
  </head>

<style type="text/css">

img.privew {
    height: 100px;
    border: 1px solid #e0e0e0;
    width: 100%;
}
.col-md-3.img {
    margin-top: 10px;
}

</style>
<body class="" style="overflow: auto !important;">
  <div class="wrapper" style="overflow: auto !important;">
    <!-- include navbar.php here -->
    <?php include_once('inc/navbar.php');?>
    <!-- include navbar.php here -->

    <div class="main-panel ps-container ps-theme-default ps-active-y" data-ps-id="17311806-fdb4-3c63-4aa5-9896dd7868a3">
      <!-- include header.php here -->
      <?php include_once('inc/header.php');?>
      <!-- include header.php here -->

      <!-- main content body start-->
      <div class="content">
        <div class="container-fluid">
          <div class="row">
              <div class="col-sm-8 ml-auto mr-auto">
                <div class="card">
                  <div class="card-header card-header-danger theme-color">
                    <h4 class="card-title"><?php echo $pageName;?></h4>
                  </div>

                   <div class="card-body">
                    <div class="card">
                      <div class="card-body">
                        <form action="add-gallery.php" method="post" enctype="multipart/form-data">

                          <div class="row" style="padding: 20px;">
                            <div class="col-md-12">
                              <div class="input-group">
                                 <input type="file" id="upload_file" name="upload_file[]" accept="image/*" class="btn btn-default  fileinput-exists" onchange="preview_image();" multiple/>
                              </div>

                               <div class="row" id="image_preview"></div>
                            </div>
                          </div>
                          <hr>
                          <button type="submit" class="btn btn-danger" type="submit" name="uplode_media" value="submit">UPLODE</button>
                          <div class="clearfix"></div>
                        </form>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
          </div>
        </div>
      </div>
      <!-- main content body end-->

       <!-- add more button start -->
      <div class="btn-float-bottom-right">
        <a href="view-gallery.php" class="theme-btn" rel="tooltip" data-original-title="Go Back"><i class="material-icons">reply</i></a>
      </div>
      <!-- add more button start -->

      <!-- incude footer.php here-->
      <?php include_once('inc/footer.php'); ?>
      <!-- incude footer.php here-->

    </div><!-- main panel end -->
  </div><!-- wrapper end -->
  <!-- include js.php here -->
  <?php include_once('inc/js.php'); ?>


<script>
  $(document).ready(function() {
      $('form').ajaxForm(function() {
          alert("Your Details Updated Succesfully...!");
          window.location.reload(true);
      });
  });

  function preview_image() {
      var total_file = document.getElementById("upload_file").files.length;
      for (var i = 0; i < total_file; i++) {
          $('#image_preview').append("<div class='col-md-3 img'><img class='privew' src='" + URL.createObjectURL(event.target.files[i]) + "'></div>");
      }
  }
</script>

</body>
</html>