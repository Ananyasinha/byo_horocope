<?php 
require_once('include/config.php');

/*if(isset($_POST['send'])){
 $name     = mysqli_real_escape_string($conn, $_POST['name']);
 $email    = mysqli_real_escape_string($conn,$_POST['email']);
 $country  = mysqli_real_escape_string($conn,$_POST['country']);
 $phone_no = mysqli_real_escape_string($conn,$_POST['phone_no']);
 $meassge  = mysqli_real_escape_string($conn,$_POST['meassge']);

   $insert = "INSERT INTO `contact_query`(`name`,`email`,`country`,`phone_no`,`message`,`created_on`) VALUES ('$name','$email','$country','$phone_no','$meassge','$datetime')";
   $inserted = $conn->query($insert);
   if($inserted){
     $msg ="Thank You For you Intrest..!  ";
   }else{
     $msg1 ="Something went wrong, Please try again.";
   }
}
*/
  $select = "SELECT * FROM pages WHERE page_id=7";
  $selected = $conn->query($select);
  $row = $selected->fetch_assoc();
  $content =$row['page_content'];
  $title =$row['page_title'];
  $page_name =$row['page_name'];
  $ban_content =$row['banner_content'];
  $sub_title=$row['page_sub_title'];

  $selectQ = "SELECT * FROM general_details";
  $selectedQ = $conn->query($selectQ);
  $rowQ = $selectedQ->fetch_assoc();


  include ('include/header.php');
?>
<style type="text/css">
  .alert-dismissible{
    text-align: center;
  }
  th {
    width: 135px;
    text-align: center;
 }
 tr.tbl {
     height: 50px;
     text-align: center;
 }
</style>
    <section id="inner-page-banner" class="inner-about">
        <div class="container">
            <div class="page-heading">
                <h1><?php echo ucfirst($page_name);?></h1>
          </div>

        </div>
        <div class="brad">
            <div class="container">
                <ul class="breadcrumb">
                    <li><a href="index.php">Home</a></li>
                    <li>Contact Us</li>
                </ul>
            </div>
        </div>
    </section>

    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-5 re-con">
                    <h4>Contact Info</h4>
                    <h5>Head office</h5>
                    <ul class="reach-us">
                        <li><i class="fa fa-map-marker" aria-hidden="true"></i>
                              <?php echo $address;?>
                            <!--   Genesis IT Innovations Limited No : 17,
                            <br> Third Floor, First main road, Vasanath Nagar,
                            <br>Bangalore - 560 052. -->
                        </li>
                        <li><i class="fa fa-volume-control-phone" aria-hidden="true"></i> <?php echo $contact;?></li>
                        <li><i class="fa fa-envelope" aria-hidden="true"></i> <a href="mailto:sales@gitil.com"> <?php echo $email;?></a></li>
                    </ul>
                </div>
                <div class="col-md-7 con-mar">
                    <h4>Get in touch</h4>
                  <form method="post">
                        <div class="row">
                          <div class="col-md-10 col-md-offset-1">
                            <div class="alert alert-success alert-dismissible success_show" style="display:none">
                               <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong class="success_msg"></strong> 
                             </div>

                             <div class="alert alert-danger alert-dismissible error_show" style="display:none">
                               <button type="button" class="close" data-dismiss="alert">&times;</button>
                              <strong class="error_msg"></strong> 
                             </div>
                          </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control name" name="name" placeholder="Name" required="">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control email" name="email" placeholder="Email ID">
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <select class="form-control country" name="country">
                                        <option value="">Please Select Country</option>
                                        <?php
                                        $tblQ = "SELECT * FROM country";
                                        $countryQ = $conn->query($tblQ);
                                          while($list = $countryQ->fetch_assoc()){ ?>
                                            <option value="<?php echo $list['name']?>" data-ccode="<?php echo $list['id']?>"><?php echo $list['name']?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <input type="text" class="form-control mobile" maxlength="12" name="phone_no" placeholder="Phone No." onkeypress="return isNumber(event)">
                                </div>
                            </div>
                            <div class="col-md-12">
                                <div class="form-group">
                                    <textarea class="form-control meassge" rows="3" name="meassge" placeholder="Meassge"></textarea>
                                </div>
                            </div>
                            <div class="col-md-8"></div>
                            <div class="col-md-4 subm">
                                <div class="form-group text-right">
                                    <input type="submit" name="send" id="submit" class="btn submitbtn contactbu reqback" value="SUBMIT">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="col-md-12">
                    <div class="contdetails">
                    <?php
                        $tblQ = "SELECT * FROM multiple_address WHERE page_id=7";
                        $list = $conn->query($tblQ);
                    ?>

                        <table>
                            <tbody>
                                <tr>
                                    <th>Location</th>
                                    <th>Name</th>
                                    <th>Contact No.</th>
                                    <th>Remark</th>
                                </tr>
                                <?php 
                                   while($alist = $list->fetch_assoc()){
                                 ?>
                                <tr class='tbl'>
                                   
                                    <td><?php echo $alist['location']?></td>
                                    <td><?php echo $alist['name']?></td>
                                    <td><?php echo $alist['contact']?>
                                    <td><?php echo $alist['address'];?><br>
                                       <!--  <br> # 306,Twin Complex,Phase 1,
                                        <br> Opp Marol Fire Station, Marol Naka, Andheri
                                        <br> (East), Mumbai 400 059. -->
                                    </td>
                                </tr>
                                <?php } ?>
                               
                            </tbody>
                        </table>
                    </div>

                </div>
                <div class="col-md-12">
                    <iframe src="<?php echo $map_url;?>" width="100%" height="370" allowfullscreen=""></iframe>
                </div>
            </div>
        </div>
    </section>
    <?php include ('include/footer.php');?>
    <script type="text/javascript" src="js/common.js"></script>

    <script type="text/javascript">
      function isNumber(evt) {
          evt = (evt) ? evt : window.event;
          var charCode = (evt.which) ? evt.which : evt.keyCode;
          if (charCode > 31 && (charCode < 48 || charCode > 57)) {
              return false;
          }
          return true;
      }
    </script>